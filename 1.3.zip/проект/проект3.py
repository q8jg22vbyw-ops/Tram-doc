from PyQt6 import uic
from PyQt6.QtWidgets import *
from PyQt6.QtGui import QDesktopServices
from PyQt6.QtNetwork import QNetworkAccessManager, QNetworkRequest, QNetworkReply
import sys
import webbrowser
import sqlite3
import requests
from urllib.parse import urlparse


bd = sqlite3.connect('Индивидуальный_проект')
bd_cur = bd.cursor()
bd_cur.execute("""CREATE TABLE IF NOT EXISTS users(
    NAME TEXT,
    URL TEXT
)""")
bd.commit()


class menu(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('проект.ui', self)
        w = 661
        h = 572
        self.setFixedSize(w, h)
        self.initUI()

    def initUI(self):
        self.pushButton.clicked.connect(self.newW)

    def newW(self):
        self.hide()
        self.a = schema()
        self.a.show()


class schema(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('schema.ui', self)
        w = 661
        h = 572
        self.setFixedSize(w, h)
        self.initUI()

    def initUI(self):
        self.pushButton.clicked.connect(self.newW2)
        self.pushButton_2.clicked.connect(self.lastW2)

    def lastW2(self):
        self.hide()
        self.d = menu()
        self.d.show()

    def newW2(self):
        self.hide()
        self.b = model1()
        self.b.show()

class model1(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('модель 1.ui', self)
        w = 1022
        h = 812
        self.setFixedSize(w, h)
        self.initUI()

    def initUI(self):
        self.pushButton.clicked.connect(self.dow)
        self.pushButton_2.clicked.connect(self.lastW)
        self.pushButton_3.clicked.connect(self.dow1)

    def dow(self):
        url = 'https://disk.yandex.ru/i/BZpXm1IHr3hk8A'
        webbrowser.open(url)

    def dow1(self):
        self.hide()
        self.d = doc1()
        self.d.show()

    def lastW(self):
        self.hide()
        self.c = schema()
        self.c.show()

class doc1(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('dow1.ui', self)
        w = 661
        h = 572
        self.setFixedSize(w, h)
        load_db()
        self.initUI()

    def initUI(self):
        self.pushButton.clicked.connect(self.newW)
        self.pushButton_2.clicked.connect(self.download_doc)
        self.pushButton_3.clicked.connect(self.admin)
        self.pushButton_4.clicked.connect(self.geo)

    def geo(self):
        self.hide()
        self.c = geo1()
        self.c.show()

    def download_doc(self):
        if self.listWidget.selectedItems():
             dowload()
        else:
            QMessageBox.critical(
                self,
                'Ошибка',
                'Выбери компонент бортового оборудования.',
                QMessageBox.StandardButton.Ok
            )

    def dowload(self):
        s = self.listWidget.currentItem()
        a = s.text()
        b = sqlite3.connect('Индивидуальный_проект')
        cursor = b.cursor()
        cursor.execute("SELECT * FROM users WHERE NAME = ?", (a,))
        url = cursor.fetchone()
        b.close()
        webbrowser.open(url)
            
   
    def newW(self):
        self.hide()
        self.a = model1()
        self.a.show()

    def admin(self):
        self.hide()
        self.b = adm()
        self.b.show()

    def load_db(self):
        bd = sqlite3.connect('Индивидуальный_проект')
        cursor = bd.cursor()
        cursor.execute("SELECT NAME FROM users")
        components = cursor.fetchall()
        bd.close()
        self.listWidget.clear()
        for i in components:
            self.listWidget.addItem(i[0]) 


class adm(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('вход.ui', self)
        w = 661
        h = 572
        self.setFixedSize(w, h)
        self.initUI()

    def initUI(self):
        self.pushButton_2.clicked.connect(self.lastW3)
        self.pushButton.clicked.connect(self.vchod)

    def vchod(self):
        self.parol = self.plainTextEdit.toPlainText()
        parol = 'GETadm'
        if self.parol == parol:
            self.hide()
            self.b = adm_menu()
            self.b.show()
        else:
            QMessageBox.warning(
                self,
                'Ошибка',
                'Неверный пароль!',
                QMessageBox.StandardButton.Ok
            )
            self.plainTextEdit.clear()
            self.plainTextEdit.setFocus()

    def lastW3(self):
        self.hide()
        self.a = doc1()
        self.a.show()

class geo1(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('1sch.ui', self)
        w = 1450
        h = 875
        self.setFixedSize(w, h)
        self.initUI()
        
    def initUI(self):
        self.pushButton.clicked.connect(self.geo2)
        self.pushButton_2.clicked.connect(self.geo3)
        self.pushButton_3.clicked.connect(self.geo4)
        self.pushButton_4.clicked.connect(self.back)

    def geo2(self):
        self.hide()
        self.g1 = geo2()
        self.g1.show()

    def geo3(self):
        self.hide()
        self.g2 = geo3()
        self.g2.show()

    def geo4(self):
        self.hide()
        self.g3 = geo4()
        self.g3.show()

    def back(self):
        self.hide()
        self.g4 = doc1()
        self.g4.show()

class geo2(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('2sch.ui', self)
        w = 1375
        h = 750
        self.setFixedSize(w, h)
        self.initUI()
        
    def initUI(self):
        self.pushButton.clicked.connect(self.geo1)
        self.pushButton_3.clicked.connect(self.geo3)
        self.pushButton_2.clicked.connect(self.geo4)
        self.pushButton_4.clicked.connect(self.back)

    def geo1(self):
        self.hide()
        self.g1 = geo1()
        self.g1.show()

    def geo3(self):
        self.hide()
        self.g2 = geo3()
        self.g2.show()

    def geo4(self):
        self.hide()
        self.g3 = geo4()
        self.g3.show()

    def back(self):
        self.hide()
        self.g4 = doc1()
        self.g4.show()
        
        
class adm_menu(adm):
    def __init__(self):
        super().__init__()
        uic.loadUi('adm_menu.ui', self)
        w = 661
        h = 572
        self.setFixedSize(w, h)
        load_db()
        self.initUI()

    def initUI(self):
        self.pushButton.clicked.connect(self.remove)
        self.pushButton_2.clicked.connect(self.back)
        self.pushButton_3.clicked.connect(self.newEl)

    def remove(self):
        if self.listWidget.selectedItems():
            s = self.listWidget.currentItem()
            a = s.text()
            bd = sqlite3.connect('Индивидуальный_проект')
            cursor = bd.cursor()
            cursor.execute("DELETE FROM users WHERE NAME = ?", (a,))
            bd.commit()
            bd.close()
            load_bd()
        else:
            QMessageBox.critical(
                self,
                'Ошибка',
                'Выбери компонент бортового оборудования.',
                QMessageBox.StandardButton.Ok
            )

    def newEl(self):
        a = dial(self)
        b = a.exec()
        
    def back(self):
        self.hide()
        self.a = doc1()
        self.a.show()

    def load_db(self):
        bd = sqlite3.connect('Индивидуальный_проект')
        cursor = bd.cursor()
        cursor.execute("SELECT NAME FROM users")
        components = cursor.fetchall()
        bd.close()
        self.listWidget.clear()
        for i in components:
            self.listWidget.addItem(i[0]) 


class geo3(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('3sch.ui', self)
        w = 1350
        h = 800
        self.setFixedSize(w, h)
        self.initUI()
        
    def initUI(self):
        self.pushButton.clicked.connect(self.geo1)
        self.pushButton_2.clicked.connect(self.geo2)
        self.pushButton_4.clicked.connect(self.geo4)
        self.pushButton_3.clicked.connect(self.back)

    def geo1(self):
        self.hide()
        self.g1 = geo1()
        self.g1.show()

    def geo2(self):
        self.hide()
        self.g2 = geo2()
        self.g2.show()

    def geo4(self):
        self.hide()
        self.g3 = geo4()
        self.g3.show()

    def back(self):
        self.hide()
        self.g4 = doc1()
        self.g4.show()

        
class geo4(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('4sch.ui', self)
        w = 985
        h = 731
        self.setFixedSize(w, h)
        self.initUI()
        
    def initUI(self):
        self.pushButton.clicked.connect(self.geo1)
        self.pushButton_2.clicked.connect(self.geo2)
        self.pushButton_3.clicked.connect(self.geo3)
        self.pushButton_4.clicked.connect(self.back)

    def geo1(self):
        self.hide()
        self.g1 = geo1()
        self.g1.show()

    def geo2(self):
        self.hide()
        self.g2 = geo2()
        self.g2.show()

    def geo3(self):
        self.hide()
        self.g3 = geo3()
        self.g3.show()

    def back(self):
        self.hide()
        self.g4 = doc1()
        self.g4.show()

        
class dial(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        uic.loadUi('dial1.ui', self)
        buttonBox.rejected.connect(self.reject)
        buttonBox.accepted.connect(self.accept)
        self.initUI()

    def initUI(self):
        self.buttonBox.button(QDialogButtonBox.StandardButton.Ok).clicked.connect(self.on_yes)
        self.buttonBox.button(QDialogButtonBox.StandardButton.Cancel).clicked.connect(self.on_no)
        
    def on_no(self):
         self.reject()

    def on_yes(self):
        if self.lineEdit.text() != '' and self.lineEdit_2.text() != '':
            a = self.lineEdit_2.text()
            if check_url(a):
                save_in_bd()
                self.accept()
            else:
                self.lineEdit_2.clear()
                QMessageBox.critical(
                    self,
                    'Ошибка',
                    'Введите корректный URL',
                    QMessageBox.StandardButton.Ok
                )
        else:
            QMessageBox.critical(
                    self,
                    'Ошибка',
                    'Заполните все поля.',
                    QMessageBox.StandardButton.Ok
                )
            
    def save_in_bd(self):
        global bd_cur, bd
        a = self.lineEdit.text()
        b = self.lineEdit_2.text()
        bd_cur.execute("SELECT NAME FROM users")
        if bd_cur.fetchone() is None:
            bd_cur.execute(f"INSERT INTO users VALUES (?, ?)", (a, b))
            bd.commit()
        
    def check_url(url):
        try:
            a = requests.head(url, timeout=5, allow_redirects=True)
            return response.status_code == 200
        except requests.exceptions.RequestException:
            return False


if __name__== '__main__':
    app = QApplication(sys.argv)
    ex = menu()
    ex.show()
    sys.exit(app.exec())
